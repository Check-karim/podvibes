var ep = {
    btn : document.getElementById('publish_ep'),
}

$(ep.btn).click('click', (event)=>{
   
})