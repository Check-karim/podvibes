<?php 
$body= 'div-block';
require ('./components/header.php') ?>
<?php require ('./components/nav.php') ?>
<div class="container-fluid home-container">
	<div class="row justify-content-end">
		<div class="col-md-8 p-5 pb-2 text-center">
			<h1 class='p-2  home-text-shadow'>PODVIBES EAR CANDY FOR YOU</h1>
		</div>
		<br/>
		
	</div>
  <div class="row justify-content-start">
    <div class="col-md-6 home-text">
			<p class='pt-1 fs-2'>
        PODVIBES, THE SHOW THAT EXPLORES THE 
        WORLD OF MUSIC, CULTURE ,AND TECHNOLOGY, 
        AS WELL AS OTHER TOPICS THAT INSPIRE AND INFLUENCE 
        OUR LIVES.
      </p>
		</div>
  </div>
</div>
<?php require ('./components/footer.php'); ?>